package BookstoreAPI.dto;

import BookstoreAPI.model.Book;

import org.elasticsearch.index.mapper.MapperService;

import BookstoreAPI.dto.BookDTO;

public interface BookMapper {
       BookMapper INSTANCE = MapperService.getMapper(BookMapper.class);

    BookDTO toBookDTO(Book book);
    Book toBook(BookDTO bookDTO);
}
