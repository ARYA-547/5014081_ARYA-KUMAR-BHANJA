package BookstoreAPI.controller;

import BookstoreAPI.model.Customer;
import BookstoreAPI.dto.CustomerDTO;
import BookstoreAPI.model.Book;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    // POST: Create a new customer
    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        // Logic to save the customer (simulated with a placeholder)
        customer.setId(1L); // This would be generated in a real scenario
        return customer;
    }

    @PostMapping("/register")
    public Customer registerCustomer(@RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("password") String password) {
        // Logic to create a new customer (simulated with a placeholder)
        Customer customer = new Customer();
        customer.setId(2L); // This would be generated in a real scenario
        customer.setName(name);
        customer.setEmail(email);
        customer.setPassword(password);
        return customer;
    }

    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

}