package BookstoreAPI.controller;

import org.springframework.web.bind.annotation.*;

import com.google.common.net.HttpHeaders;

import BookstoreAPI.dto.BookDTO;
import BookstoreAPI.exception.BookNotFoundException;
import BookstoreAPI.model.Book;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {
    // Add methods to handle HTTP requests here
    // GET: Retrieve all books

    @GetMapping
    public List<Book> getAllBooks() {
        // Logic to retrieve books
        List<Book> books = new ArrayList<>();
        Book book = new Book();
        book.setId(1L);
        book.setTitle("Sample Book");
        book.setAuthor("Sample Author");
        book.setPrice(9.99);
        book.setIsbn("123-4567890123");
        books.add(book);

        // Create custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "This is a custom header for all books");

        // Return ResponseEntity with the list of books and custom headers
        return new ResponseEntity<>(books, headers, HttpStatus.OK);
    }

    // POST: Add a new book
    @PostMapping
    public Book addBook(@RequestBody Book book) {
        // Logic to add book
        return book;
    }

    // PUT: Update a book by ID
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        // Logic to update book
        return book;
    }

    // DELETE: Remove a book by ID
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        // Logic to delete book
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        Book book = new Book();
        book.setId(id);
        book.setTitle("Sample Book");
        book.setAuthor("Sample Author");
        book.setPrice(9.99);
        book.setIsbn("123-4567890123");

        // Create custom headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "This is a custom header");

        // Return ResponseEntity with the book and custom headers
        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }

    @GetMapping("/search")
    public List<Book> getBooksByTitleAndAuthor(@RequestParam(required = false) String title,
            @RequestParam(required = false) String author) {
        // Logic to filter books (simulated with a placeholder)
        List<Book> books = new ArrayList<>();

        // Sample logic for filtering based on title and author
        if ("Sample Book".equals(title) && "Sample Author".equals(author)) {
            Book book = new Book();
            book.setId(1L);
            book.setTitle(title);
            book.setAuthor(author);
            book.setPrice(9.99);
            book.setIsbn("123-4567890123");
            books.add(book);
        }
        return books;
    }

    // POST: Add a new book with a 201 Created status
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Book addBook(@RequestBody Book book) {
        // Logic to add the book (simulated with a placeholder)
        book.setId(1L); // This would be generated in a real scenario
        return book;
    }

    // DELETE: Remove a book by ID with a 204 No Content status
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteBook(@PathVariable Long id) {
        // Logic to delete the book (simulated with a placeholder)
    }

    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        // Logic to retrieve the book by ID (simulated with a placeholder)
        if (id != 1L) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }

        Book book = new Book();
        book.setId(id);
        book.setTitle("Sample Book");
        book.setAuthor("Sample Author");
        book.setPrice(9.99);
        book.setIsbn("123-4567890123");

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "This is a custom header");

        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }

    private BookService bookService;

    @PostMapping
    public ResponseEntity<BookDTO> createBook(@Valid @RequestBody BookDTO bookDTO) {
        BookDTO createdBook = bookService.createBook(bookDTO);
        return new ResponseEntity<>(createdBook, HttpStatus.CREATED);
    }

}