package BookstoreAPI.exception;

public class BookNotFoundException {

}
