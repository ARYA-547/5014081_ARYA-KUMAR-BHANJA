package BookstoreAPI.exception;

public class GlobalExceptionHandler {

}
