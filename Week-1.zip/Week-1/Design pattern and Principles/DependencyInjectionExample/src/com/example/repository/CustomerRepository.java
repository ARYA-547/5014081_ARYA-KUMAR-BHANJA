package com.example.repository;

public interface CustomerRepository {
    String findCustomerById(String id);
}
