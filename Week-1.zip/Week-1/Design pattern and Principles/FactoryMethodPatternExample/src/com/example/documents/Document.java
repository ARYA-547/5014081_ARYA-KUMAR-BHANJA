package com.example.documents;

public interface Document {
    void open();
    void save();
    void close();
}
