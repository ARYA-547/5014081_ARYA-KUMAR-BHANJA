package com.example.payment;

public interface PaymentStrategy {
    void pay(double amount);
}
