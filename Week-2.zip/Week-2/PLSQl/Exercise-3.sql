USE cognizant;

DELIMITER $$

CREATE PROCEDURE ProcessMonthlyInterest()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE account_id INT;
    DECLARE account_balance DECIMAL(15, 2);
    DECLARE account_cursor CURSOR FOR
        SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN account_cursor;

    read_loop: LOOP
        FETCH account_cursor INTO account_id, account_balance;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Calculate new balance with 1% interest
        UPDATE Accounts
        SET Balance = account_balance * 1.01
        WHERE AccountID = account_id;
    END LOOP;

    CLOSE account_cursor;
END$$

DELIMITER ;

DELIMITER $$

CREATE PROCEDURE UpdateEmployeeBonus(
    IN department_id INT,
    IN bonus_percentage DECIMAL(5, 2)
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE employee_id INT;
    DECLARE employee_salary DECIMAL(15, 2);
    DECLARE employee_cursor CURSOR FOR
        SELECT EmployeeID, Salary FROM Employees WHERE DepartmentID = department_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN employee_cursor;

    read_loop: LOOP
        FETCH employee_cursor INTO employee_id, employee_salary;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Update employee salary with bonus percentage
        UPDATE Employees
        SET Salary = employee_salary + (employee_salary * bonus_percentage / 100)
        WHERE EmployeeID = employee_id;
    END LOOP;

    CLOSE employee_cursor;
END$$

DELIMITER ;

DELIMITER $$

CREATE PROCEDURE TransferFunds(
    IN source_account_id INT,
    IN target_account_id INT,
    IN transfer_amount DECIMAL(15, 2)
)
BEGIN
    DECLARE insufficient_funds BOOLEAN DEFAULT FALSE;
    DECLARE source_balance DECIMAL(15, 2);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log general error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES ('An error occurred during fund transfer', NOW());
        -- Rollback transaction
        ROLLBACK;
    END;

    START TRANSACTION;

    -- Check if source account has sufficient funds
    SELECT Balance INTO source_balance FROM Accounts WHERE AccountID = source_account_id;
    IF source_balance < transfer_amount THEN
        SET insufficient_funds = TRUE;
    END IF;

    IF insufficient_funds THEN
        -- Log specific error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES (CONCAT('Insufficient funds in account ', source_account_id), NOW());
        -- Rollback transaction
        ROLLBACK;
    ELSE
        -- Deduct amount from source account
        UPDATE Accounts
        SET Balance = Balance - transfer_amount
        WHERE AccountID = source_account_id;

        -- Add amount to target account
        UPDATE Accounts
        SET Balance = Balance + transfer_amount
        WHERE AccountID = target_account_id;

        COMMIT;
    END IF;
END$$

DELIMITER ;


