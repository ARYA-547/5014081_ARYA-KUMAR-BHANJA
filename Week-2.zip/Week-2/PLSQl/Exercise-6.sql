use cognizant;
DELIMITER $$

CREATE PROCEDURE GenerateMonthlyStatements()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE customer_id INT;
    DECLARE customer_name VARCHAR(100);
    DECLARE transaction_date DATE;
    DECLARE transaction_amount DECIMAL(15, 2);
    DECLARE transaction_type ENUM('Deposit', 'Withdrawal');

    DECLARE customer_cursor CURSOR FOR
        SELECT DISTINCT c.CustomerID, c.Name
        FROM Customers c
        JOIN Transactions t ON c.CustomerID = t.CustomerID
        WHERE MONTH(t.TransactionDate) = MONTH(CURDATE()) AND YEAR(t.TransactionDate) = YEAR(CURDATE());

    DECLARE transaction_cursor CURSOR FOR
        SELECT TransactionDate, Amount, TransactionType
        FROM Transactions
        WHERE CustomerID = customer_id AND MONTH(TransactionDate) = MONTH(CURDATE()) AND YEAR(TransactionDate) = YEAR(CURDATE());

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN customer_cursor;

    read_customers: LOOP
        FETCH customer_cursor INTO customer_id, customer_name;
        IF done THEN
            LEAVE read_customers;
        END IF;

        -- Print statement header for the customer
        SELECT CONCAT('Monthly Statement for ', customer_name, ' (Customer ID: ', customer_id, ')') AS StatementHeader;

        OPEN transaction_cursor;

        read_transactions: LOOP
            FETCH transaction_cursor INTO transaction_date, transaction_amount, transaction_type;
            IF done THEN
                LEAVE read_transactions;
            END IF;

            -- Print each transaction
            SELECT CONCAT(transaction_date, ' - ', transaction_type, ': ', transaction_amount) AS TransactionDetail;
        END LOOP;

        CLOSE transaction_cursor;
    END LOOP;

    CLOSE customer_cursor;
END$$

DELIMITER ;


DELIMITER $$

CREATE PROCEDURE ApplyAnnualFee()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE account_id INT;
    DECLARE annual_fee DECIMAL(15, 2) DEFAULT 50.00; -- Example fee

    DECLARE account_cursor CURSOR FOR
        SELECT AccountID FROM Accounts;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN account_cursor;

    read_accounts: LOOP
        FETCH account_cursor INTO account_id;
        IF done THEN
            LEAVE read_accounts;
        END IF;

        -- Deduct annual fee from the account balance
        UPDATE Accounts
        SET Balance = Balance - annual_fee
        WHERE AccountID = account_id;
    END LOOP;

    CLOSE account_cursor;
END$$

DELIMITER ;

DELIMITER $$

CREATE PROCEDURE UpdateLoanInterestRates()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE loan_id INT;
    DECLARE new_interest_rate DECIMAL(5, 2) DEFAULT 4.5; -- Example new interest rate

    DECLARE loan_cursor CURSOR FOR
        SELECT LoanID FROM Loans;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN loan_cursor;

    read_loans: LOOP
        FETCH loan_cursor INTO loan_id;
        IF done THEN
            LEAVE read_loans;
        END IF;

        -- Update the interest rate for each loan
        UPDATE Loans
        SET InterestRate = new_interest_rate
        WHERE LoanID = loan_id;
    END LOOP;

    CLOSE loan_cursor;
END$$

DELIMITER ;


