
CREATE TABLE cognizant.customers (
    CustomerID int(10) PRIMARY KEY,
    Name VARCHAR(100),
    DOB DATE,
    Balance int(10),
    LastModified DATE
);

CREATE TABLE Accounts (
    AccountID int(100) PRIMARY KEY,
    CustomerID int(100),
    AccountType VARCHAR(20),
    Balance int(10),
    LastModified DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Transactions (
    TransactionID int(50) PRIMARY KEY,
    AccountID int(100),
    TransactionDate DATE,
    Amount int(50),
    TransactionType VARCHAR(10),
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);


CREATE TABLE Loans (
    LoanID int(100) PRIMARY KEY,
    CustomerID int(50),
    LoanAmount int(100),
    InterestRate int(50),
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Employees (
    EmployeeID int(100) PRIMARY KEY,
    Name VARCHAR(100),
    Position VARCHAR(50),
    Salary int(10),
    Department VARCHAR(50),
    HireDate DATE
); 


INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (1, 'John Doe', STR_TO_DATE('1985-05-15', '%Y-%m-%d'), 1000, NOW());

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (2, 'Jane Smith', STR_TO_DATE('1990-07-20', '%Y-%m-%d'), 1500, Now());

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (1, 1, 'Savings', 1000, Now());

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (2, 2, 'Checking', 1500, Now());

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, 1, Now(), 200, 'Deposit');

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (2, 2, Now(), 300, 'Withdrawal');

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 5000, 5, NOW(), DATE_ADD(NOW(), INTERVAL 60 MONTH));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', STR_TO_DATE('2015-06-15', '%Y-%m-%d'));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', STR_TO_DATE('2017-03-20', '%Y-%m-%d'));















