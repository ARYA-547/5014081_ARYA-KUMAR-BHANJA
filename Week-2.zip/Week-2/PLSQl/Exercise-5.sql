use cognizant;
DELIMITER $$

CREATE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    SET NEW.LastModified = NOW();
END$$

DELIMITER ;

CREATE TABLE AuditLog (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    TransactionID INT,
    Action VARCHAR(50),
    LogDate DATETIME,
    Amount DECIMAL(15, 2),
    AccountID INT
);

DELIMITER $$

CREATE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TransactionID, Action, LogDate, Amount, AccountID)
    VALUES (NEW.TransactionID, 'INSERT', NOW(), NEW.Amount, NEW.AccountID);
END$$

DELIMITER ;


CREATE TABLE Transactions (
    TransactionID INT AUTO_INCREMENT PRIMARY KEY,
    AccountID INT,
    TransactionType ENUM('Deposit', 'Withdrawal'),
    Amount DECIMAL(15, 2),
    TransactionDate DATETIME
);
DELIMITER $$

CREATE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
BEGIN
    DECLARE current_balance DECIMAL(15, 2);
    
    -- Fetch the current balance of the account
    SELECT Balance INTO current_balance FROM Accounts WHERE AccountID = NEW.AccountID;

    -- Check if the transaction is a withdrawal
    IF NEW.TransactionType = 'Withdrawal' THEN
        -- Ensure withdrawal amount does not exceed current balance
        IF NEW.Amount > current_balance THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient funds for withdrawal';
        END IF;
    END IF;

    -- Check if the transaction is a deposit
    IF NEW.TransactionType = 'Deposit' THEN
        -- Ensure deposit amount is positive
        IF NEW.Amount <= 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Deposit amount must be positive';
        END IF;
    END IF;
END$$

DELIMITER ;

