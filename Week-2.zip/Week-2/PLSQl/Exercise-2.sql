USE cognizant;

DELIMITER $$

CREATE PROCEDURE SafeTransferFunds(
    IN sender_account_id INT,
    IN receiver_account_id INT,
    IN transfer_amount DECIMAL(15,2)
)
BEGIN
    DECLARE insufficient_funds BOOLEAN DEFAULT FALSE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log general error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES ('An error occurred during fund transfer', NOW());
        -- Rollback transaction
        ROLLBACK;
    END;

    START TRANSACTION;

    -- Check if sender has sufficient funds
    IF (SELECT Balance FROM Accounts WHERE AccountID = sender_account_id) < transfer_amount THEN
        SET insufficient_funds = TRUE;
    END IF;

    IF insufficient_funds THEN
        -- Log specific error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES (CONCAT('Insufficient funds in account ', sender_account_id), NOW());
        -- Rollback transaction
        ROLLBACK;
    ELSE
        -- Deduct amount from sender's account
        UPDATE Accounts
        SET Balance = Balance - transfer_amount
        WHERE AccountID = sender_account_id;

        -- Add amount to receiver's account
        UPDATE Accounts
        SET Balance = Balance + transfer_amount
        WHERE AccountID = receiver_account_id;

        COMMIT;
    END IF;
END$$

DELIMITER ;


DELIMITER $$

CREATE PROCEDURE UpdateSalary(
    IN employee_id INT,
    IN increase_percentage DECIMAL(5, 2)
)
BEGIN
    DECLARE employee_not_found BOOLEAN DEFAULT FALSE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log general error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES ('An error occurred while updating salary', NOW());
        -- Rollback transaction
        ROLLBACK;
    END;

    START TRANSACTION;

    -- Check if employee exists
    IF (SELECT COUNT(*) FROM Employees WHERE EmployeeID = employee_id) = 0 THEN
        SET employee_not_found = TRUE;
    END IF;

    IF employee_not_found THEN
        -- Log specific error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES (CONCAT('Employee ID ', employee_id, ' does not exist'), NOW());
        -- Rollback transaction
        ROLLBACK;
    ELSE
        -- Update employee salary
        UPDATE Employees
        SET Salary = Salary + (Salary * increase_percentage / 100)
        WHERE EmployeeID = employee_id;

        COMMIT;
    END IF;
END$$

DELIMITER ;

DELIMITER $$

CREATE PROCEDURE AddNewCustomer(
    IN customer_id INT,
    IN customer_name VARCHAR(100),
    IN dob DATE,
    IN balance DECIMAL(15, 2)
)
BEGIN
    DECLARE customer_exists BOOLEAN DEFAULT FALSE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Log general error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES ('An error occurred while adding a new customer', NOW());
        -- Rollback transaction
        ROLLBACK;
    END;

    START TRANSACTION;

    -- Check if customer already exists
    IF (SELECT COUNT(*) FROM Customers WHERE CustomerID = customer_id) > 0 THEN
        SET customer_exists = TRUE;
    END IF;

    IF customer_exists THEN
        -- Log specific error
        INSERT INTO ErrorLogs (ErrorMessage, ErrorDate)
        VALUES (CONCAT('Customer ID ', customer_id, ' already exists'), NOW());
        -- Rollback transaction
        ROLLBACK;
    ELSE
        -- Insert new customer
        INSERT INTO Customers (CustomerID, Name, DOB, Balance)
        VALUES (customer_id, customer_name, dob, balance);

        COMMIT;
    END IF;
END$$

DELIMITER ;



