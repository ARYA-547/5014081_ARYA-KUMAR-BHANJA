use cognizant;
DELIMITER $$

-- Function to get customer balance
CREATE FUNCTION GetCustomerBalance (
    p_customer_id INT
) RETURNS DECIMAL(15, 2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_balance DECIMAL(15, 2);
    SELECT Balance INTO v_balance FROM Customers WHERE CustomerID = p_customer_id;
    RETURN v_balance;
END$$

DELIMITER ;



DELIMITER $$

-- Function to calculate annual salary
CREATE FUNCTION CalculateAnnualSalary (
    p_employee_id INT
) RETURNS DECIMAL(15, 2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_salary DECIMAL(15, 2);
    SELECT Salary * 12 INTO v_salary FROM Employees WHERE EmployeeID = p_employee_id;
    RETURN v_salary;
END$$

DELIMITER ;


DELIMITER $$

-- Function to get total balance of a customer across all accounts
CREATE FUNCTION GetTotalBalance (
    p_customer_id INT
) RETURNS DECIMAL(15, 2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_total_balance DECIMAL(15, 2);
    SELECT SUM(Balance) INTO v_total_balance FROM Accounts WHERE CustomerID = p_customer_id;
    RETURN v_total_balance;
END$$

DELIMITER ;

