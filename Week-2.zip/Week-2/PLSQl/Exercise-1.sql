USE cognizant;

DELIMITER $$

CREATE PROCEDURE ApplyInterestRateDiscount()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_customer_id INT;
    DECLARE v_age INT;
    DECLARE customer_cursor CURSOR FOR
        SELECT CustomerID, TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
        FROM Customers;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN customer_cursor;
    read_loop: LOOP
        FETCH customer_cursor INTO v_customer_id, v_age;
        IF done THEN
            LEAVE read_loop;
        END IF;

        IF v_age > 60 THEN
            UPDATE Loans
            SET InterestRate = InterestRate - 1
            WHERE CustomerID = v_customer_id;
        END IF;
    END LOOP;

    CLOSE customer_cursor;
    COMMIT;
END$$

DELIMITER ;

CALL ApplyInterestRateDiscount();

DELIMITER $$
CREATE PROCEDURE SetVIPStatus()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_customer_id INT;
    DECLARE v_balance DECIMAL(15, 2);
    DECLARE customer_cursor CURSOR FOR
        SELECT CustomerID, Balance
        FROM Customers;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN customer_cursor;
    read_loop: LOOP
        FETCH customer_cursor INTO v_customer_id, v_balance;
        IF done THEN
            LEAVE read_loop;
        END IF;

        IF v_balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = TRUE
            WHERE CustomerID = v_customer_id;
        END IF;
    END LOOP;

    CLOSE customer_cursor;
    COMMIT;
END$$

DELIMITER ;

CALL SetVIPStatus();


DELIMITER $$

CREATE PROCEDURE SendLoanReminders()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_customer_id INT;
    DECLARE v_end_date DATE;
    DECLARE loan_cursor CURSOR FOR
        SELECT CustomerID, EndDate
        FROM Loans
        WHERE EndDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN loan_cursor;
    read_loop: LOOP
        FETCH loan_cursor INTO v_customer_id, v_end_date;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SELECT CONCAT('Reminder: Customer ID ', v_customer_id, ' has a loan due on ', v_end_date) AS ReminderMessage;
    END LOOP;

    CLOSE loan_cursor;
END$$

DELIMITER ;

CALL SendLoanReminders();


