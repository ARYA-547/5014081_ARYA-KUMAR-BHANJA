use cognizant;

DELIMITER $$

CREATE FUNCTION CalculateAge(dob DATE) RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE age INT;
    SET age = TIMESTAMPDIFF(YEAR, dob, CURDATE());
    RETURN age;
END$$

DELIMITER ;


DELIMITER $$

CREATE FUNCTION CalculateMonthlyInstallment(
    loan_amount DECIMAL(15, 2),
    annual_interest_rate DECIMAL(5, 2),
    loan_duration_years INT
) RETURNS DECIMAL(15, 2)
DETERMINISTIC
BEGIN
    DECLARE monthly_interest_rate DECIMAL(5, 4);
    DECLARE number_of_payments INT;
    DECLARE monthly_installment DECIMAL(15, 2);

    SET monthly_interest_rate = annual_interest_rate / 12 / 100;
    SET number_of_payments = loan_duration_years * 12;

    SET monthly_installment = loan_amount * monthly_interest_rate / 
        (1 - POWER(1 + monthly_interest_rate, -number_of_payments));

    RETURN monthly_installment;
END$$

DELIMITER ;

DELIMITER $$

CREATE FUNCTION HasSufficientBalance(account_id INT, amount DECIMAL(15, 2)) RETURNS BOOLEAN
READS SQL DATA
BEGIN
    DECLARE account_balance DECIMAL(15, 2);
    DECLARE sufficient_balance BOOLEAN;

    SELECT Balance INTO account_balance FROM Accounts WHERE AccountID = account_id;
    
    IF account_balance >= amount THEN
        SET sufficient_balance = TRUE;
    ELSE
        SET sufficient_balance = FALSE;
    END IF;

    RETURN sufficient_balance;
END$$

DELIMITER ;

